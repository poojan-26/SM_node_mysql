module.exports = (function () {
  let data = {
      host:"localhost",
      port:3030,
      user:"root",
      password:""
  } 
  return data;
})();